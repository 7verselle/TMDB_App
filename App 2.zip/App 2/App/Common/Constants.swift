import Foundation

struct Constants {
    
    struct ui {
        static let defaultCellIdentifier = "Cell"
        static let movieSavedMessage = "Movie saved!"
        static let okMessage = "Cool 👌"
    }
    
}
