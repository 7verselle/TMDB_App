import UIKit

class WatchLaterViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var movies: [MovieRealm] = []
    
    let realmGetFunc = RealmFunc()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.movies = realmGetFunc.getMovies()
        tableView.reloadData()
    }
}

extension WatchLaterViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
}

extension WatchLaterViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let Nib = UINib(nibName:"WatchLaterTableViewCell" , bundle: nil)
        tableView.register(Nib, forCellReuseIdentifier: "WatchLaterTableViewCell")
        if let cell = tableView.dequeueReusableCell(withIdentifier: "WatchLaterTableViewCell", for: indexPath) as? WatchLaterTableViewCell {
            cell.configure(movie: movies[indexPath.row])
            cell.textLabel?.text = movies[indexPath.row].title
            
            return cell
        }
        
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let identifire = String(describing: DetailsViewController.self)
        let storyboard = UIStoryboard(name: "Main" , bundle: nil)
        if let detailsViewController = storyboard.instantiateViewController(identifier: identifire)
            as? DetailsViewController {
            let movie = movies[indexPath.row]
            let movieUI = MovieUI(title: movie.title,
                                  popularity: movie.popularity,
                                  overview: movie.overview,
                                  id: movie.id,
                                  backdropPath: movie.backdropPath,
                                  mediaType: movie.mediaType,
                                  posterPath: movie.posterPath)
            detailsViewController.movie = movieUI
            self.navigationController?.pushViewController(detailsViewController, animated: true)
        }
    }
}
