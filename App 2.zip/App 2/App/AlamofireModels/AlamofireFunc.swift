import Foundation
import Alamofire

class AlamofireFunc {
    
    func requestVideoDetails(_ id: Int, completion: @escaping(([VideoResults]) -> ())) {
        let url = "https://api.themoviedb.org/3/movie/\(id)/videos?api_key=fd3ebcb0c4e2f9a4dc69070661262e8d"
        AF.request(url).responseJSON { response in
            let decoder = JSONDecoder()
            guard let responceData = response.data else { return }
            guard let data = try? decoder.decode(JSONVideo.self, from: responceData) else { return }
            guard let videos = data.results else { return }
            completion(videos)
        }
    }
}
