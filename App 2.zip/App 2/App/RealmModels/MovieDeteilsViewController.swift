//
//  MovieDeteilsViewController.swift
//  L_9
//
//  Created by Valery on 13.11.2021.
//

import UIKit
import SDWebImage
import RealmSwift

class MovieDeteilsViewController: UIViewController {
    
    let realm = try? Realm()
    
//    @IBOutlet weak var posterImageView: UIImageView!
//    @IBOutlet weak var titleLable: UILabel!
//    @IBOutlet weak var oveviewLabel: UILabel!
//
    var movie: Movie?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var imageURLString = ""
        if let backdropPath = self.movie?.posterPath{
            imageURLString = "https://image.tmdb.org/t/p/w500/" + backdropPath
            let imageURL = URL(string: imageURLString)
            posterImageView.sd_setImage(with: imageURL, completed: nil)
        }
        
        self.titleLable.text = movie?.title ?? "No title"
        self.oveviewLabel.text = movie?.overview
       
    }

    @IBAction func addToListButtonPressed(_ sender: Any) {
        
        let movieRealm = MovieRealm()
        
        movieRealm.title = self.movie?.title ?? ""
        movieRealm.popularity = self.movie?.popularity ?? 0.0
        movieRealm.overview = self.movie?.overview ?? ""
        movieRealm.id = self.movie?.id ?? 0
        movieRealm.backdropPath = self.movie?.backdropPath ?? ""
        movieRealm.mediaType = self.movie?.mediaType ?? ""
        movieRealm.posterPath = self.movie?.posterPath ?? ""

   
        try? realm?.write {
            realm?.add(movieRealm)
        }
    }
}
